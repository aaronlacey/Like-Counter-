function addLike(id){
    document.getElementById(id).innerText++
}